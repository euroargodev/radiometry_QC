etirr <- function(wave) {
	data(thuillier)
	return(0.1 * approx(thuillier$wave,thuillier$F0,wave)$y)
}
