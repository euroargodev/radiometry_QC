simple.atm <- function(month, day, sunzen, w, om.aer =  0.98, F.aer = 0.75, tau.a = 0.10) {
	if(is.na(sunzen)) return(rep(NA, length(w)))
	t <- exp(-(
		0.5 * tau.r(w) +
		tau.oz(w,du = 350) +
		(1 - om.aer * F.aer) * tau.a) / cos(sunzen *pi/180))
	es <- cos(sunzen*pi/180) * t * etirr(w) * orbex(month,day)
	return(es)
}
